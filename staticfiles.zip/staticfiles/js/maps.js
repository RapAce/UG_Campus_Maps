var markers=[];
var x=0;
var map;


function myMap()
{
          var center = new google.maps.LatLng(5.650588,-0.187057);
          var origin = {lat: 5.650588, lng: -0.187057};

          map = new google.maps.Map(document.getElementById('map'), {
          zoom: 17,
          center: origin
        });
        var clickHandler = new ClickEventHandler(map, origin);


        var bounds2 = [
          {lat: 5.6660769234947095, lng: -0.19059449981273247},
          {lat: 5.666763962441066, lng: -0.1779756148088154},
          {lat: 5.656118835823307, lng: -0.18038423226903433},
          {lat: 5.649045129526939, lng: -0.1810065047604894},
          {lat: 5.640806169634043, lng: -0.17848047293978198},
          {lat: 5.633633873504186, lng: -0.17741569170527782},
          {lat: 5.627040145413529, lng: -0.19213499148327173},
          {lat: 5.646004100413743, lng: -0.20465152847305035},
          {lat: 5.658709338231878, lng: -0.20461934196487164},
        ];

        var uniofgh = new google.maps.Polygon({paths: bounds2});

        google.maps.event.addListener(map, 'click', function(e) {

             if(google.maps.geometry.poly.containsLocation(e.latLng, uniofgh)!=true)
             {
                alert("Please Choose A Venue Or Location Within The University Of Ghana");
             }
        });

        // Create the search box and link it to the UI element.
        var input = document.getElementById('pac-input');
        var searchBox = new google.maps.places.SearchBox(input);
        map.controls[google.maps.ControlPosition.TOP_LEFT].push(input);

        // Bias the SearchBox results towards current map's viewport.
        map.addListener('bounds_changed', function() {
          searchBox.setBounds(map.getBounds());
        });


        // Listen for the event fired when the user selects a prediction and retrieve
        // more details for that place.
        searchBox.addListener('places_changed', function() {
          var places = searchBox.getPlaces();

          if (places.length == 0) {
            return;
          }

          // Clear out the old markers.
          markers.forEach(function(marker) {
            marker.setMap(null);
          });
          markers = [];

          // For each place, get the icon, name and location.
          var bounds = new google.maps.LatLngBounds();
          places.forEach(function(place) {
            if (!place.geometry) {
              console.log("Returned place contains no geometry");
              return;
            }
            var icon = {
              url: place.icon,
              size: new google.maps.Size(71, 71),
              origin: new google.maps.Point(0, 0),
              anchor: new google.maps.Point(17, 34),
              scaledSize: new google.maps.Size(25, 25)
            };

            // Create a marker for each place.
            markers.push(new google.maps.Marker({
              map: map,
              title: place.name,
              position: place.geometry.location
            }));

            if (place.geometry.viewport) {
              // Only geocodes have viewport.
              bounds.union(place.geometry.viewport);
            } else {
              bounds.extend(place.geometry.location);
            }
          });
          map.fitBounds(bounds);
        });;
}

      /**
       * @constructor
       */
      var ClickEventHandler = function(map, origin) {
        this.origin = origin;
        this.map = map;

        // Listen for clicks on the map.
        this.map.addListener('click', this.handleClick.bind(this));
      };

      ClickEventHandler.prototype.handleClick = function(event) {
        //alert(event.latLng);

        document.getElementById("id_longitude").readOnly=true;
        document.getElementById("id_latitude").readOnly=true;
        var bounds2 = [
          {lat: 5.6660769234947095, lng: -0.19059449981273247},
          {lat: 5.666763962441066, lng: -0.1779756148088154},
          {lat: 5.656118835823307, lng: -0.18038423226903433},
          {lat: 5.649045129526939, lng: -0.1810065047604894},
          {lat: 5.640806169634043, lng: -0.17848047293978198},
          {lat: 5.633633873504186, lng: -0.17741569170527782},
          {lat: 5.627040145413529, lng: -0.19213499148327173},
          {lat: 5.646004100413743, lng: -0.20465152847305035},
          {lat: 5.658709338231878, lng: -0.20461934196487164},
        ];

        var uniofgh = new google.maps.Polygon({paths: bounds2});



             if(google.maps.geometry.poly.containsLocation(event.latLng, uniofgh))
             {
                if (document.getElementById("id_name").value!="")
              {
              document.getElementById("id_name").value ="";
              document.getElementById("id_address").value ="";
              document.getElementById("id_phonenumber").value="";
              document.getElementById("id_openinghours").value="";
              document.getElementById("id_type").value="";
              }

                document.getElementById("id_latitude").value=event.latLng.lat();
                document.getElementById("id_longitude").value=event.latLng.lng();
                placeMarker(map, event.latLng);
             }



        // If the event has a placeId, use it.
        if (event.placeId) {
          //alert(event.placeId);



          var infowindow = new google.maps.InfoWindow();
          var service = new google.maps.places.PlacesService(map);

          if(google.maps.geometry.poly.containsLocation(event.latLng, uniofgh))
             {
                if (x>0)
    {
        for (var i = 0; i < markers.length; i++)
        {
          markers[i].setMap(null);
        }
        markers=[];
    }
             }



        service.getDetails({
          placeId: event.placeId
        }, function(place, status) {
          if (status === google.maps.places.PlacesServiceStatus.OK) {
             if(google.maps.geometry.poly.containsLocation(event.latLng, uniofgh))
             {
                var marker = new google.maps.Marker({
              //map: map,
              position: place.geometry.location
            });
            if (place.name!="")
            {
                marker.setMap(map);
                markers.push(marker);
            }



              infowindow.setContent('<strong>Name: ' + place.name + '</strong><br>Address: ' +
                place.formatted_address +'<br>Lattitude: '+event.latLng.lat()+'<br>Longitude: '+event.latLng.lng()+'<br>Phone Number: ' +place.international_phone_number
                +'<br>Venue Type: '+place.types+'<br>');
              infowindow.open(map,marker);
              x++;



              document.getElementById("id_name").value =place.name;
              document.getElementById("id_address").value =place.formatted_address;
              document.getElementById("id_phonenumber").value=place.international_phone_number;
              document.getElementById("id_type").value=place.types;

              var url=place.photos[0].getUrl({'maxWidth': 1900, 'maxHeight': 1080});
              document.getElementById("id_imageurl").value=url;

              document.getElementById("id_openinghours").value=place.opening_hours.weekday_text;
             }
             else{alert("Please Choose A Venue Or Location Within The University Of Ghana")}


















          }
        })
          // Calling e.stop() on the event prevents the default info window from
          // showing.
          // If you call stop here when there is no placeId you will prevent some
          // other map click event handlers from receiving the event.

          e.stop();
        }

};

function placeMarker(map, location)
{
    if (x>0)
    {
        for (var i = 0; i < markers.length; i++)
        {
          markers[i].setMap(null);
        }
        markers=[];
    }


  var marker = new google.maps.Marker({
    position: location,
    map: map,
  });
  var infowindow = new google.maps.InfoWindow({
    content: 'Latitude: ' + location.lat() + '<br>Longitude: ' + location.lng()
  });
  markers.push(marker)
  infowindow.open(map,marker);

  x++;
}

